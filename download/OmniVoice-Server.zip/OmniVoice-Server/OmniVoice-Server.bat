@echo off
chcp 65001 >nul 2>&1
title OmniVoice TTS - Painel de Controle
color 0E

:menu
cls
echo.
echo ============================================
echo   OmniVoice TTS - Painel de Controle
echo ============================================
echo.

set "OV_STATUS=PARADO"
set "CF_STATUS=PARADO"
set "TUNNEL_URL=N/A"

powershell -Command "try { Invoke-WebRequest -Uri 'http://localhost:7860/' -TimeoutSec 3 -UseBasicParsing -ErrorAction Stop; Write-Output 'ONLINE' } catch { Write-Output 'OFFLINE' }" > "%TEMP%\ov_st.txt" 2>&1
findstr /C:"ONLINE" "%TEMP%\ov_st.txt" >nul
if not errorlevel 1 set "OV_STATUS=ONLINE"

tasklist /FI "IMAGENAME eq cloudflared.exe" 2>nul | findstr /I "cloudflared" >nul
if not errorlevel 1 set "CF_STATUS=ONLINE"

set "CF_LOG=%TEMP%\cloudflared_tunnel.log"
if exist "%CF_LOG%" (
    for /f "tokens=*" %%a in ('powershell -Command "if (Test-Path '%CF_LOG%') { $c = Get-Content '%CF_LOG%' -Raw -ErrorAction SilentlyContinue; if ($c -match 'https://([a-z0-9\-]+)\.trycloudflare\.com') { Write-Output \"https://$($matches[1]).trycloudflare.com\" } }" 2^>nul') do (
        set "TUNNEL_URL=%%a"
    )
)

echo  STATUS:
echo    OmniVoice:    %OV_STATUS%
echo    Tunnel:       %CF_STATUS%
echo    URL:          %TUNNEL_URL%
echo.
echo ============================================
echo.
echo  [1] Iniciar Servidor      (2o plano, invisivel)
echo  [2] Parar Servidor
echo  [3] Reiniciar Servidor
echo  [4] Ver GPU               (nvidia-smi)
echo  [0] Sair
echo.
set /p "OPCAO=  Escolha: "

if "%OPCAO%"=="1" goto :iniciar
if "%OPCAO%"=="2" goto :parar
if "%OPCAO%"=="3" goto :reiniciar
if "%OPCAO%"=="4" goto :gpu
if "%OPCAO%"=="0" goto :sair
goto :menu

:iniciar
cscript //nologo "%~dp0start_hidden.vbs"
echo Servidor iniciado! Aguarde 25s...
timeout /t 25 /nobreak >nul
pause
goto :menu

:parar
taskkill /F /IM cloudflared.exe >nul 2>&1
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq OmniVoice*" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq Tunnel*" >nul 2>&1
echo Servidor parado!
timeout /t 3 /nobreak >nul
goto :menu

:reiniciar
taskkill /F /IM cloudflared.exe >nul 2>&1
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq OmniVoice*" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq Tunnel*" >nul 2>&1
timeout /t 3 /nobreak >nul
cscript //nologo "%~dp0start_hidden.vbs"
echo Reiniciando... Aguarde 25s...
timeout /t 25 /nobreak >nul
pause
goto :menu

:gpu
nvidia-smi
pause
goto :menu

:sair
exit /b 0
