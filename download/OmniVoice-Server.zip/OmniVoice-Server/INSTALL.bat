@echo off
chcp 65001 >nul 2>&1
title OmniVoice TTS - Instalador
color 0B

echo.
echo  ============================================
echo    OmniVoice TTS - Instalador
echo  ============================================
echo.

set "OV_DIR=%~dp0"

echo [1/5] Verificando internet...
ping -n 2 www.google.com >nul 2>&1
if errorlevel 1 (
    echo     [ERRO] Sem internet! Conecte e tente de novo.
    pause
    exit /b 1
)
echo     [OK] Internet.

echo [2/5] Verificando GPU...
nvidia-smi >nul 2>&1
if errorlevel 1 (
    echo     [AVISO] GPU NVIDIA nao encontrada. OmniVoice precisa de GPU.
    pause
    exit /b 1
)
echo     [OK] GPU NVIDIA encontrada.

echo [3/5] Verificando Miniconda...
if exist "C:\Users\Administrador\Miniconda3\Scripts\conda.exe" (
    echo     [OK] Miniconda encontrada.
    goto :check_ov
)

echo     [INFO] Baixando Miniconda...
powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe' -OutFile '%TEMP%\Miniconda3.exe' -UseBasicParsing"
if not exist "%TEMP%\Miniconda3.exe" (
    echo     [ERRO] Falha ao baixar. Instale manualmente.
    pause
    exit /b 1
)
start /wait "" "%TEMP%\Miniconda3.exe" /S /InstallationType=JustMe /AddToPath=1 /RegisterPython=0
del /f "%TEMP%\Miniconda3.exe" >nul 2>&1
echo     [OK] Miniconda instalada.

:check_ov
echo [4/5] Verificando omnivoice-demo...
call "C:\Users\Administrador\Miniconda3\Scripts\activate.bat" >nul 2>&1
pip show omnivoice-demo >nul 2>&1
if errorlevel 1 (
    echo     [INFO] Instalando omnivoice-demo (pode demorar)...
    pip install omnivoice-demo
    echo     [OK] omnivoice-demo instalado.
) else (
    echo     [OK] omnivoice-demo ja instalado.
)

echo [5/5] Verificando cloudflared...
where cloudflared >nul 2>&1
if errorlevel 1 (
    echo     [INFO] Instalando cloudflared...
    winget install --id Cloudflare.cloudflared --accept-package-agreements --accept-source-agreements >nul 2>&1
    echo     [OK] cloudflared instalado.
) else (
    echo     [OK] cloudflared encontrado.
)

echo.
echo  Criando atalhos na area de trabalho...
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%USERPROFILE%\Desktop\OmniVoice Server.lnk'); $s.TargetPath = '%OV_DIR%start_hidden.vbs'; $s.WorkingDirectory = '%OV_DIR%'; $s.IconLocation = 'shell32.dll,13'; $s.Save()"
powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%USERPROFILE%\Desktop\Parar OmniVoice.lnk'); $s.TargetPath = '%OV_DIR%stop.bat'; $s.WorkingDirectory = '%OV_DIR%'; $s.IconLocation = 'shell32.dll,27'; $s.Save()"
echo     [OK] Atalhos criados!

echo.
echo  ============================================
echo    INSTALACAO CONCLUIDA!
echo  ============================================
echo.
echo  "OmniVoice Server"   = Iniciar (invisivel)
echo  "Parar OmniVoice"    = Parar tudo
echo  "OmniVoice-Server"   = Painel de controle
echo.
pause
