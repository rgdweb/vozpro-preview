@echo off
chcp 65001 >nul 2>&1

echo Parando servidor atual...
taskkill /F /IM cloudflared.exe >nul 2>&1
taskkill /F /IM python.exe >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq OmniVoice*" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq Tunnel*" >nul 2>&1
timeout /t 3 /nobreak >nul

echo Reiniciando servidor...
cscript //nologo "%~dp0start_hidden.vbs"
echo Aguardando 25s...
timeout /t 25 /nobreak >nul
echo Pronto!
timeout /t 3 /nobreak >nul
