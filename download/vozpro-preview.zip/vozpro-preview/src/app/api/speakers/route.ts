import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/speakers — Lista locutores oficiais ativos
export async function GET() {
  try {
    const speakers = await db.speaker.findMany({
      where: { isActive: true },
      orderBy: { createdAt: 'asc' },
    })
    return NextResponse.json(speakers)
  } catch (error) {
    console.error('[/api/speakers] Erro:', error)
    return NextResponse.json([], { status: 500 })
  }
}
