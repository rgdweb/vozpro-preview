@echo off
chcp 65001 >nul 2>&1
title OmniVoice TTS - Parando Servidor
color 0C

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║     OmniVoice TTS - Parando Servidor         ║
echo  ╚══════════════════════════════════════════════╝
echo.

set "LOG_FILE=%~dp0server.log"
echo [%date% %time%] PARANDO SERVIDOR... >> "%LOG_FILE%"

:: Matar tunnel cloudflare
echo [1/3] Parando tunnel Cloudflare...
taskkill /F /IM cloudflared.exe >nul 2>&1
if errorlevel 1 (
    echo     [INFO] Nenhum tunnel ativo.
) else (
    echo     [OK] Tunnel parado.
)

:: Matar OmniVoice (python rodando omnivoice-demo)
echo.
echo [2/3] Parando OmniVoice...
for /f "tokens=2" %%a in ('tasklist /FI "IMAGENAME eq python.exe" /FO LIST ^| findstr /B "PID:"') do (
    taskkill /F /PID %%a >nul 2>&1
)
echo     [OK] Processos Python encerrados.

:: Matar processos do cmd que possam estar rodando o iniciar.bat
echo.
echo [3/3] Limpando processos residuais...
taskkill /F /FI "WINDOWTITLE eq OmniVoice*" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq Tunnel*" >nul 2>&1
echo     [OK] Limpeza concluida.

echo.
echo [%date% %time%] SERVIDOR PARADO. >> "%LOG_FILE%"
echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║       SERVIDOR OMNIVOICE PARADO!             ║
echo  ╚══════════════════════════════════════════════╝
echo.
echo  Para iniciar de novo, duplo clique em "OmniVoice Server".
echo.
timeout /t 5 /nobreak >nul
