# VozPro — Preview do Repositorio de Analise

Arquivos sincronizados do Oracle Cloud (`147.15.77.137`) para analise.

## Estado Atual (2026-06-05)

### Arquitetura
```
Browser (page.tsx)
  → Next.js API /api/generate (route.ts)
    → Cloudflare Tunnel
      → GPU local (omnivoice_gpu.py) RTX 3060 12GB (port 7860)
```

### Fluxo Locutores Oficiais (clone_fast)

1. **Frontend** (`page.tsx`): User seleciona Locutor → `selectedSpeakerFile = "aline_dias_locucao_calma.wav"` → envia `POST /api/generate` com `voiceMode: 'clone_fast'`
2. **API** (`route.ts`): Recebe `speakerFile`, busca `Speaker` no DB, obtém `refAudioUrl`, monta payload `{ voice_mode: 'clone_fast', speaker_id: speakerFile, ref_audio_url: refAudioUrl }`
3. **GPU** (`omnivoice_gpu.py`): Recebe payload, FLUXO 1 clone_fast, baixa WAV se não existe localmente, valida com soundfile, gera audio

### Banco de Dados

**Speaker table** (1 registro):
| Campo | Valor |
|-------|-------|
| id | `328897b7-705b-45a3-a611-ecd5dfb26809` |
| name | Aline Dias — Locução Calma |
| speakerFile | `aline_dias_locucao_calma.wav` (slug) |
| refAudioUrl | `https://api.cvmnews.com.br/audios/ref/6a179b4e3fc9d_1779931982.wav` (URL real do WAV) |
| isActive | true |

**Speaker model** (schema.prisma):
- `speakerFile` (unique) — slug amigável
- `refAudioUrl` — URL real do arquivo no servidor Oracle (para GPU baixar)

### Problema Atual

GPU baixa o WAV com sucesso mas `model.generate()` retorna:
```
Error opening <_io.BytesIO object>: Format not recognised.
```

O arquivo WAV é válido (PCM 16-bit, 44100Hz, stereo — validado por ffmpeg e Python wave module no Oracle).
O problema está no `omnivoice_gpu.py` linha ~373: `model.generate(ref_audio=tmp_ref_path)` — o modelo OmniVoice não está conseguindo ler o WAV baixado. Possível causa: incompatibilidade de samplerate (44100 vs 24000 que o modelo espera) ou formato do arquivo após download no Windows.

### Arquivos do Repo

```
src/app/
  page.tsx                          # Frontend principal (3180 linhas)
  api/
    generate/route.ts               # API de geracao (356 linhas)
    admin/speakers/convert/route.ts # Ativa/desativa Locutores
    speakers/route.ts               # Lista Locutores
  admin/page.tsx                    # Painel admin
  lib/db.ts                         # Prisma DB connection

prisma/
  schema.prisma                     # Schema completo do banco

gpu/
  omnivoice_gpu.py                  # Servidor GPU (526 linhas) — COM AUTOCURA

nginx/
  omnivoice.conf                    # Config Nginx (sorteiomax + cvmnews + default)

php/
  get_tunnel.php                    # Descobre URL do Cloudflare Tunnel

database/
  dump.sql                          # Dump completo PostgreSQL
  speaker_table.txt                 # Tabela Speaker atual
```
