@echo off
chcp 65001 >nul 2>&1
title OmniVoice TTS - Parando Servidor
color 0C

echo.
echo ============================================
echo   OmniVoice TTS - Parando Servidor
echo ============================================
echo.

echo [1/3] Parando tunnel Cloudflare...
taskkill /F /IM cloudflared.exe >nul 2>&1

echo [2/3] Parando OmniVoice (python)...
taskkill /F /IM python.exe >nul 2>&1

echo [3/3] Fechando janelas residuais...
taskkill /F /FI "WINDOWTITLE eq OmniVoice*" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq Tunnel*" >nul 2>&1

echo.
echo   Servidor OmniVoice PARADO!
echo.
echo   Para iniciar de novo, duplo clique em "OmniVoice Server".
echo.
timeout /t 5 /nobreak >nul
