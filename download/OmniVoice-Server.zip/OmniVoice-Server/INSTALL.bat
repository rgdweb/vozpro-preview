@echo off
chcp 65001 >nul 2>&1
title OmniVoice TTS - Instalador
color 0B

echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║     OmniVoice TTS - Instalador Completo      ║
echo  ║  Verifica e instala tudo automaticamente     ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: ============================================
:: PASTA DO PROJETO
:: ============================================
set "OV_DIR=%~dp0"
set "OV_DIR=%OV_DIR:~0,-1%"

:: ============================================
:: 1. VERIFICAR CONEXAO COM INTERNET
:: ============================================
echo [1/6] Verificando internet...
ping -n 2 www.google.com >nul 2>&1
if errorlevel 1 (
    echo     [ERRO] Sem conexao com internet!
    echo     Conecte-se e tente novamente.
    pause
    exit /b 1
)
echo     [OK] Internet conectada.

:: ============================================
:: 2. VERIFICAR/INSTALAR NVIDIA CUDA (Driver)
:: ============================================
echo.
echo [2/6] Verificando driver NVIDIA / CUDA...
nvidia-smi >nul 2>&1
if errorlevel 1 (
    echo     [AVISO] Driver NVIDIA nao encontrado ou GPU indisponivel.
    echo     O OmniVoice PRECISA de placa NVIDIA com CUDA.
    echo.
    echo     Deseja baixar o driver NVIDIA? (abre o site)
    choice /C SN /M "Baixar driver agora? [S]im [N]ao"
    if errorlevel 2 goto :skip_cuda
    start https://www.nvidia.com/Download/index.aspx
    echo     Abriu o site da NVIDIA. Instale o driver e rode este script de novo.
    pause
    exit /b 1
) else (
    for /f "tokens=*" %%a in ('nvidia-smi --query-gpu=name --format=csv,noheader 2^>nul') do echo     [OK] GPU encontrada: %%a
)
:skip_cuda

:: ============================================
:: 3. VERIFICAR/INSTALAR MINICONDA
:: ============================================
echo.
echo [3/6] Verificando Miniconda...

set "CONDA_FOUND=0"
set "CONDA_PATH="

if exist "C:\Users\Administrador\Miniconda3\Scripts\conda.exe" (
    set "CONDA_PATH=C:\Users\Administrador\Miniconda3"
    set "CONDA_FOUND=1"
)
if exist "C:\Users\%USERNAME%\Miniconda3\Scripts\conda.exe" (
    set "CONDA_PATH=C:\Users\%USERNAME%\Miniconda3"
    set "CONDA_FOUND=1"
)
if exist "C:\ProgramData\Miniconda3\Scripts\conda.exe" (
    set "CONDA_PATH=C:\ProgramData\Miniconda3"
    set "CONDA_FOUND=1"
)

if %CONDA_FOUND%==0 (
    where conda >nul 2>&1
    if not errorlevel 1 set "CONDA_FOUND=1"
)

if %CONDA_FOUND%==1 (
    echo     [OK] Miniconda encontrada.
    if not defined CONDA_PATH (
        for /f "tokens=*" %%a in ('where conda 2^>nul') do set "CONDA_PATH=%%~dpa.."
    )
    goto :check_omnivoice
)

:install_conda
echo     [INFO] Miniconda nao encontrada. Baixando instalador...
echo     (Isso pode demorar alguns minutos...)

set "CONDA_INSTALLER=%TEMP%\Miniconda3-latest-Windows-x86_64.exe"

powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe' -OutFile '%CONDA_INSTALLER%' -UseBasicParsing"

if not exist "%CONDA_INSTALLER%" (
    echo     [ERRO] Falha ao baixar Miniconda!
    echo     Baixe manualmente em: https://repo.anaconda.com/miniconda/Miniconda3-latest-Windows-x86_64.exe
    pause
    exit /b 1
)

echo     [INFO] Instalando Miniconda (modo silencioso)...
start /wait "" "%CONDA_INSTALLER%" /S /InstallationType=JustMe /AddToPath=1 /RegisterPython=0
del /f "%CONDA_INSTALLER%" >nul 2>&1

if exist "C:\Users\%USERNAME%\Miniconda3\Scripts\conda.exe" (
    set "CONDA_PATH=C:\Users\%USERNAME%\Miniconda3"
    echo     [OK] Miniconda instalada com sucesso!
) else if exist "C:\ProgramData\Miniconda3\Scripts\conda.exe" (
    set "CONDA_PATH=C:\ProgramData\Miniconda3"
    echo     [OK] Miniconda instalada com sucesso!
) else (
    echo     [ERRO] Miniconda instalada mas nao encontrada.
    echo     Feche e abra um NOVO cmd, depois rode de novo.
    pause
    exit /b 1
)

call "%CONDA_PATH%\Scripts\activate.bat" "%CONDA_PATH%"

:check_omnivoice
:: ============================================
:: 4. VERIFICAR/INSTALAR OMNIVOICE-DEMO
:: ============================================
echo.
echo [4/6] Verificando OmniVoice Demo...

call "%CONDA_PATH%\Scripts\activate.bat" "%CONDA_PATH%"

pip show omnivoice-demo >nul 2>&1
if errorlevel 1 (
    echo     [INFO] omnivoice-demo nao encontrado. Instalando...
    echo     (Pode demorar 5 a 15 minutos na primeira vez)
    echo     Ele vai baixar o modelo de IA completo.
    echo.
    pip install omnivoice-demo
    
    if errorlevel 1 (
        echo     [ERRO] Falha ao instalar omnivoice-demo!
        pause
        exit /b 1
    )
    echo     [OK] omnivoice-demo instalado com sucesso!
) else (
    echo     [OK] omnivoice-demo ja esta instalado.
)

:: ============================================
:: 5. VERIFICAR/INSTALAR CLOUDFLARED
:: ============================================
echo.
echo [5/6] Verificando cloudflared (tunnel)...

set "CF_EXE="
if exist "C:\Program Files\cloudflared\cloudflared.exe" set "CF_EXE=C:\Program Files\cloudflared\cloudflared.exe"
if exist "C:\Program Files (x86)\cloudflared\cloudflared.exe" set "CF_EXE=C:\Program Files (x86)\cloudflared\cloudflared.exe"
if exist "%LOCALAPPDATA%\cloudflared\cloudflared.exe" set "CF_EXE=%LOCALAPPDATA%\cloudflared\cloudflared.exe"

if "%CF_EXE%"=="" (
    where cloudflared >nul 2>&1
    if not errorlevel 1 (
        for /f "tokens=*" %%a in ('where cloudflared 2^>nul') do set "CF_EXE=%%a"
    )
)

if "%CF_EXE%"=="" (
    echo     [INFO] cloudflared nao encontrado. Instalando...
    winget install --id Cloudflare.cloudflared --accept-package-agreements --accept-source-agreements >nul 2>&1
    
    if errorlevel 1 (
        echo     [AVISO] winget falhou. Tentando download direto...
        powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.zip' -OutFile '%TEMP%\cf.zip'; Expand-Archive '%TEMP%\cf.zip' -DestinationPath '%LOCALAPPDATA%\cloudflared' -Force; Remove-Item '%TEMP%\cf.zip'"
        
        if exist "%LOCALAPPDATA%\cloudflared\cloudflared.exe" (
            set "CF_EXE=%LOCALAPPDATA%\cloudflared\cloudflared.exe"
            echo     [OK] cloudflared instalado!
        ) else (
            echo     [ERRO] Nao foi possivel instalar cloudflared!
            echo     Baixe em: https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/
            pause
            exit /b 1
        )
    ) else (
        echo     [OK] cloudflared instalado via winget!
    )
) else (
    echo     [OK] cloudflared encontrado.
)

:: ============================================
:: 6. CRIAR ATALHOS NA AREA DE TRABALHO
:: ============================================
echo.
echo [6/6] Criando atalhos na area de trabalho...

set "DESKTOP=%USERPROFILE%\Desktop"

powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\OmniVoice Server.lnk'); $s.TargetPath = '%OV_DIR%\start_hidden.vbs'; $s.WorkingDirectory = '%OV_DIR%'; $s.IconLocation = 'shell32.dll,13'; $s.Description = 'OmniVoice TTS - Iniciar Servidor'; $s.Save()"

powershell -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%DESKTOP%\Parar OmniVoice.lnk'); $s.TargetPath = '%OV_DIR%\stop.bat'; $s.WorkingDirectory = '%OV_DIR%'; $s.IconLocation = 'shell32.dll,27'; $s.Description = 'OmniVoice TTS - Parar Servidor'; $s.Save()"

echo     [OK] Atalhos criados na area de trabalho!

:: ============================================
:: PRONTO
:: ============================================
echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║          INSTALACAO CONCLUIDA!              ║
echo  ╚══════════════════════════════════════════════╝
echo.
echo  Verificado/instalado:
echo    [OK] Internet
echo    [OK] NVIDIA CUDA / GPU
echo    [OK] Miniconda + Python
echo    [OK] omnivoice-demo
echo    [OK] cloudflared (tunnel)
echo    [OK] Atalhos na area de trabalho
echo.
echo  COMO USAR:
echo    Duplo clique em "OmniVoice Server" = INICIAR (2o plano)
echo    Duplo clique em "Parar OmniVoice" = PARAR tudo
echo    OmniVoice-Server.bat = Painel de controle
echo.
pause
