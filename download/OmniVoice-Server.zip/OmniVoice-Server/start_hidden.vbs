' OmniVoice Server - Iniciador Invisivel
' Roda o iniciar.bat completamente oculto (sem nenhuma janela)

Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Caminho da pasta do script
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

' Executar o iniciar.bat invisivel
WshShell.Run """" & scriptDir & "\iniciar.bat""", 0, False
