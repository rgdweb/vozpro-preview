@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

title OmniVoice TTS - Painel de Controle
color 0E

:: ============================================
:: PAINEL DE CONTROLE - MENU INTERATIVO
:: ============================================

:menu
cls
echo.
echo  ╔══════════════════════════════════════════════╗
echo  ║       OmniVoice TTS - Painel de Controle     ║
echo  ╚══════════════════════════════════════════════╝
echo.

:: Verificar status atual
set "STATUS_OV=PARADO"
set "STATUS_CF=PARADO"
set "TUNNEL_URL=N/A"

:: Verificar OmniVoice
powershell -Command "try { Invoke-WebRequest -Uri 'http://localhost:7860/' -TimeoutSec 3 -UseBasicParsing -ErrorAction Stop; Write-Output 'ONLINE' } catch { Write-Output 'OFFLINE' }" > "%TEMP%\ov_status.txt" 2>&1
findstr /C:"ONLINE" "%TEMP%\ov_status.txt" >nul
if not errorlevel 1 set "STATUS_OV=ONLINE"

:: Verificar Cloudflared
tasklist /FI "IMAGENAME eq cloudflared.exe" 2>nul | findstr /I "cloudflared" >nul
if not errorlevel 1 set "STATUS_CF=ONLINE"

:: Tentar pegar URL do tunnel
set "CF_LOG=%TEMP%\cloudflared_tunnel.log"
if exist "%CF_LOG%" (
    for /f "tokens=*" %%a in ('powershell -Command "if (Test-Path '%CF_LOG%') { $c = Get-Content '%CF_LOG%' -Raw -ErrorAction SilentlyContinue; if ($c -match 'https://([a-z0-9\-]+)\.trycloudflare\.com') { Write-Output \"https://$($matches[1]).trycloudflare.com\" } }" 2^>nul') do (
        set "TUNNEL_URL=%%a"
    )
)

:: Mostrar status
echo  STATUS ATUAL:
echo.
if "%STATUS_OV%"=="ONLINE" (
    echo    [ONLINE ]  OmniVoice na porta 7860
) else (
    echo    [OFFLINE]  OmniVoice na porta 7860
)

if "%STATUS_CF%"=="ONLINE" (
    echo    [ONLINE ]  Tunnel Cloudflare
) else (
    echo    [OFFLINE]  Tunnel Cloudflare
)

echo.
echo    Tunnel URL: %TUNNEL_URL%
echo.

:: Verificar se esta tudo ok
if "%STATUS_OV%"=="ONLINE" if "%STATUS_CF%"=="ONLINE" (
    echo    >>> SERVIDOR FUNCIONANDO! <<<
    echo.
)

echo  ═══════════════════════════════════════════════
echo.
echo  [1] Iniciar Servidor      (tudo em 2o plano)
echo  [2] Parar Servidor
echo  [3] Reiniciar Servidor
echo  [4] Ver Log               (ultimas 30 linhas)
echo  [5] Verificar GPU         (nvidia-smi)
echo  [6] Testar Conexao        (ping tunnel)
echo  [7] Instalar / Reinstalar (roda INSTALL.bat)
echo  [0] Sair
echo.
echo  ═══════════════════════════════════════════════
echo.
set /p "OPCAO=  Escolha: "

if "%OPCAO%"=="1" goto :iniciar
if "%OPCAO%"=="2" goto :parar
if "%OPCAO%"=="3" goto :reiniciar
if "%OPCAO%"=="4" goto :ver_log
if "%OPCAO%"=="5" goto :ver_gpu
if "%OPCAO%"=="6" goto :testar
if "%OPCAO%"=="7" goto :instalar
if "%OPCAO%"=="0" goto :sair

goto :menu

:: ============================================
:: INICIAR
:: ============================================
:iniciar
echo.
echo  Iniciando servidor em segundo plano...

:: Executar o VBS (invisivel)
cscript //nologo "%~dp0start_hidden.vbs"

echo  Servidor iniciado! Aguardando 30 segundos...
timeout /t 30 /nobreak >nul

:: Tentar pegar URL nova
if exist "%CF_LOG%" (
    for /f "tokens=*" %%a in ('powershell -Command "if (Test-Path '%CF_LOG%') { $c = Get-Content '%CF_LOG%' -Raw -ErrorAction SilentlyContinue; if ($c -match 'https://([a-z0-9\-]+)\.trycloudflare\.com') { Write-Output \"https://$($matches[1]).trycloudflare.com\" } }" 2^>nul') do (
        echo  URL do tunnel: %%a
    )
)

echo.
pause
goto :menu

:: ============================================
:: PARAR
:: ============================================
:parar
echo.
echo  Parando servidor...
taskkill /F /IM cloudflared.exe >nul 2>&1
for /f "tokens=2" %%a in ('tasklist /FI "IMAGENAME eq python.exe" /FO LIST ^| findstr /B "PID:"') do (
    taskkill /F /PID %%a >nul 2>&1
)
taskkill /F /FI "WINDOWTITLE eq OmniVoice*" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq Tunnel*" >nul 2>&1
echo  Servidor parado!
timeout /t 3 /nobreak >nul
goto :menu

:: ============================================
:: REINICIAR
:: ============================================
:reiniciar
echo.
echo  Parando servidor...
taskkill /F /IM cloudflared.exe >nul 2>&1
for /f "tokens=2" %%a in ('tasklist /FI "IMAGENAME eq python.exe" /FO LIST ^| findstr /B "PID:"') do (
    taskkill /F /PID %%a >nul 2>&1
)
taskkill /F /FI "WINDOWTITLE eq OmniVoice*" >nul 2>&1
taskkill /F /FI "WINDOWTITLE eq Tunnel*" >nul 2>&1
timeout /t 3 /nobreak >nul

echo  Reiniciando servidor...
cscript //nologo "%~dp0start_hidden.vbs"
echo  Aguardando 30 segundos...
timeout /t 30 /nobreak >nul
echo  Servidor reiniciado!
pause
goto :menu

:: ============================================
:: VER LOG
:: ============================================
:ver_log
cls
echo.
echo  ═══ ULTIMAS 30 LINHAS DO LOG ═══
echo.
set "LOG_FILE=%~dp0server.log"
if exist "%LOG_FILE%" (
    powershell -Command "Get-Content '%LOG_FILE%' -Tail 30"
) else (
    echo  Nenhum log encontrado. O servidor ja foi iniciado alguma vez?
)
echo.
echo  ═════════════════════════════════
pause
goto :menu

:: ============================================
:: VER GPU
:: ============================================
:ver_gpu
cls
echo.
echo  ═══ INFORMACOES DA GPU ═══
echo.
nvidia-smi
echo.
pause
goto :menu

:: ============================================
:: TESTAR CONEXAO
:: ============================================
:testar
cls
echo.
echo  ═══ TESTANDO CONEXAO ═══
echo.

:: Testar OmniVoice local
echo  [1/3] OmniVoice local (localhost:7860)...
powershell -Command "try { $r = Invoke-WebRequest -Uri 'http://localhost:7860/' -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop; Write-Output 'OK - Status: ' + $r.StatusCode } catch { Write-Output 'FALHOU - ' + $_.Exception.Message }"

:: Testar tunnel
echo.
echo  [2/3] Tunnel Cloudflare...
if not "%TUNNEL_URL%"=="N/A" (
    powershell -Command "try { $r = Invoke-WebRequest -Uri '%TUNNEL_URL%/' -TimeoutSec 10 -UseBasicParsing -ErrorAction Stop; Write-Output 'OK - Status: ' + $r.StatusCode } catch { Write-Output 'FALHOU - ' + $_.Exception.Message }"
) else (
    echo  Tunnel nao esta ativo.
)

:: Testar sorteiomax
echo.
echo  [3/3] Servidor sorteiomax.com.br...
powershell -Command "try { $r = Invoke-WebRequest -Uri 'https://sorteiomax.com.br/omnivoice/get_tunnel.php' -TimeoutSec 10 -UseBasicParsing -ErrorAction Stop; Write-Output 'OK: ' + $r.Content } catch { Write-Output 'FALHOU - ' + $_.Exception.Message }"

echo.
pause
goto :menu

:: ============================================
:: INSTALAR
:: ============================================
:instalar
echo.
call "%~dp0INSTALL.bat"
goto :menu

:: ============================================
:: SAIR
:: ============================================
:sair
exit /b 0
