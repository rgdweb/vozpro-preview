@echo off
:: OmniVoice Server - Atalho rapido para reiniciar
:: Coloca na area de trabalho junto com os outros atalhos
chcp 65001 >nul 2>&1

echo.
echo  Parando servidor atual...
taskkill /F /IM cloudflared.exe >nul 2>&1
for /f "tokens=2 delims=," %%a in ('tasklist /FI "IMAGENAME eq python.exe" /FO CSV /NH 2^>nul') do taskkill /F /PID %%~a >nul 2>&1
timeout /t 3 /nobreak >nul

echo  Iniciando servidor...
cscript //nologo "%~dp0start_hidden.vbs"
echo  Aguardando 30s...
timeout /t 30 /nobreak >nul
echo  Pronto! Servidor reiniciado.
timeout /t 5 /nobreak >nul
