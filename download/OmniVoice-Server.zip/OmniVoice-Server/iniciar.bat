@echo off
chcp 65001 >nul 2>&1
setlocal enabledelayedexpansion

:: ============================================
:: OmniVoice TTS - Iniciar Servidor
:: (chamado pelo start_hidden.vbs)
:: ============================================

set "LOG_FILE=%~dp0server.log"

echo [%date% %time%] Iniciando OmniVoice Server... >> "%LOG_FILE%"

:: Matar processos antigos
taskkill /F /IM cloudflared.exe >nul 2>&1
timeout /t 2 /nobreak >nul

:: ============================================
:: ENCONTRAR MINICONDA
:: ============================================
set "CONDA_PATH="

if exist "C:\Users\Administrador\Miniconda3\Scripts\activate.bat" set "CONDA_PATH=C:\Users\Administrador\Miniconda3"
if exist "C:\Users\%USERNAME%\Miniconda3\Scripts\activate.bat" set "CONDA_PATH=C:\Users\%USERNAME%\Miniconda3"
if exist "C:\ProgramData\Miniconda3\Scripts\activate.bat" set "CONDA_PATH=C:\ProgramData\Miniconda3"

if not defined CONDA_PATH (
    for /f "tokens=*" %%a in ('where conda 2^>nul') do (
        set "CONDA_PATH=%%~dpa"
        set "CONDA_PATH=!CONDA_PATH:~0,-1!"
        goto :found_conda
    )
    echo [%date% %time%] [ERRO] Miniconda nao encontrada! Rode INSTALL.bat primeiro. >> "%LOG_FILE%"
    exit /b 1
)
:found_conda

echo [%date% %time%] [OK] Conda: %CONDA_PATH% >> "%LOG_FILE%"

:: ============================================
:: ENCONTRAR CLOUDFLARED
:: ============================================
set "CF_EXE="
if exist "C:\Program Files\cloudflared\cloudflared.exe" set "CF_EXE=C:\Program Files\cloudflared\cloudflared.exe"
if exist "C:\Program Files (x86)\cloudflared\cloudflared.exe" set "CF_EXE=C:\Program Files (x86)\cloudflared\cloudflared.exe"
if exist "%LOCALAPPDATA%\cloudflared\cloudflared.exe" set "CF_EXE=%LOCALAPPDATA%\cloudflared\cloudflared.exe"
where cloudflared >nul 2>&1
if not defined CF_EXE (
    for /f "tokens=*" %%a in ('where cloudflared 2^>nul') do set "CF_EXE=%%a"
)

if not defined CF_EXE (
    echo [%date% %time%] [ERRO] cloudflared nao encontrado! Rode INSTALL.bat primeiro. >> "%LOG_FILE%"
    exit /b 1
)

echo [%date% %time%] [OK] Cloudflared: %CF_EXE% >> "%LOG_FILE%"

:: ============================================
:: INICIAR OMNIVOICE (porta 7860)
:: ============================================
set "PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True"

echo [%date% %time%] Iniciando OmniVoice na porta 7860... >> "%LOG_FILE%"
start "" /B cmd /c "call "%CONDA_PATH%\Scripts\activate.bat" "%CONDA_PATH%" && set PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True && omnivoice-demo --ip 0.0.0.0 --port 7860 >> "%LOG_FILE%" 2>&1"

:: Aguardar OmniVoice subir
echo [%date% %time%] Aguardando OmniVoice subir (20s)... >> "%LOG_FILE%"
timeout /t 20 /nobreak >nul

:: Verificar se OmniVoice esta respondendo
powershell -Command "try { Invoke-WebRequest -Uri 'http://localhost:7860/' -TimeoutSec 5 -UseBasicParsing -ErrorAction Stop; Write-Output 'OMNIVOICE_OK' } catch { Write-Output 'OMNIVOICE_FAIL' }" > "%TEMP%\ov_check.txt" 2>&1

findstr /C:"OMNIVOICE_OK" "%TEMP%\ov_check.txt" >nul
if errorlevel 1 (
    echo [%date% %time%] [AVISO] OmniVoice pode nao ter subido ainda, mas tunnel vai tentar... >> "%LOG_FILE%"
) else (
    echo [%date% %time%] [OK] OmniVoice respondendo! >> "%LOG_FILE%"
)

:: ============================================
:: INICIAR TUNNEL CLOUDFLARE
:: ============================================
echo [%date% %time%] Iniciando tunnel cloudflare... >> "%LOG_FILE%"

set "CF_LOG=%TEMP%\cloudflared_tunnel.log"
if exist "%CF_LOG%" del /f "%CF_LOG%" >nul

start "" /B "%CF_EXE%" tunnel --url http://localhost:7860 --logfile "%CF_LOG%"

:: Aguardar URL do tunnel
set "TUNNEL_URL="
set /a WAITED=0

:wait_tunnel
timeout /t 3 /nobreak >nul
set /a WAITED+=3

if exist "%CF_LOG%" (
    for /f "tokens=*" %%a in ('powershell -Command "if (Test-Path '%CF_LOG%') { $c = Get-Content '%CF_LOG%' -Raw -ErrorAction SilentlyContinue; if ($c -match 'https://([a-z0-9\-]+)\.trycloudflare\.com') { Write-Output \"https://$($matches[1]).trycloudflare.com\" } }" 2^>nul') do (
        set "TUNNEL_URL=%%a"
    )
)

if defined TUNNEL_URL goto :tunnel_ready
if %WAITED% lss 60 goto :wait_tunnel

echo [%date% %time%] [ERRO] Nao conseguiu obter URL do tunnel! >> "%LOG_FILE%"
exit /b 1

:tunnel_ready
echo [%date% %time%] [OK] Tunnel: %TUNNEL_URL% >> "%LOG_FILE%"

:: ============================================
:: ATUALIZAR URL NO SERVIDOR
:: ============================================
echo [%date% %time%] Atualizando URL no servidor sorteiomax... >> "%LOG_FILE%"

set "ENCODED_URL=%TUNNEL_URL%"
set "ENCODED_URL=%ENCODED_URL:/=%%2F%"
set "ENCODED_URL=%ENCODED_URL::=%%3A%"

start "" /B /wait powershell -Command "try { $r = (Invoke-WebRequest -Uri 'https://sorteiomax.com.br/omnivoice/update_tunnel.php?tunnelUrl=%TUNNEL_URL%' -UseBasicParsing -TimeoutSec 15).Content; Write-Output $r } catch { Write-Output 'ERRO_UPDATE' }" > "%TEMP%\ov_update.txt" 2>&1

echo [%date% %time%] Resposta do servidor: >> "%LOG_FILE%"
type "%TEMP%\ov_update.txt" >> "%LOG_FILE%"

echo [%date% %time%] ============================================ >> "%LOG_FILE%"
echo [%date% %time%] SERVIDOR OMNIVOICE ATIVO! >> "%LOG_FILE%"
echo [%date% %time%] URL: %TUNNEL_URL% >> "%LOG_FILE%"
echo [%date% %time%] Para parar: duplo clique em "Parar OmniVoice" >> "%LOG_FILE%"
echo [%date% %time%] ============================================ >> "%LOG_FILE%"
